<?php
// Text
$_['text_new_subject_error']          = '%s - Paiement échoué - Commande %s';
$_['text_new_received_error']          = "Le commande n'a pas pu être traitée en raison d'une erreur dans le processus de paiement";
?>