<?php
// Heading
$_['heading_title'] = 'Error en el proceso de pago';
$_['heading_title_customer'] = 'Error en el proceso de pago';

// Text
$_['text_customer'] = '<p>Lo sentimos, su orden no ha podido ser procesada debido a un error en el proceso de pago.</p><p>Por favor, vuelva a intentar la compra revisando la información de pago.</p><p>Por favor, <a href="%s">contacte con nosotros</a> si sigue teniendo problemas con el proceso de pago.</p>';
$_['text_basket']   = 'Cesta';
$_['text_checkout'] = 'Pagar';
$_['text_error']  = 'Error';
?>