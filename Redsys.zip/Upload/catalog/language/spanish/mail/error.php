<?php
// Text
$_['text_new_subject_error']          = '%s - Error en proceso de pago - Pedido %s';
$_['text_new_received_error']          = 'La orden no ha podido ser procesada debido a un error en el proceso de pago.';
?>