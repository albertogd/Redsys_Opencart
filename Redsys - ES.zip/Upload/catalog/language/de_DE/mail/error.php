<?php
// Text
$_['text_new_subject_error']          = '%s - Zahlung fehlgeschlagen - Auftrag %s';
$_['text_new_received_error']          = 'Der Auftrag konnte aufgrund eines Fehlers in der Zahlung verarbeitet werden';
?>