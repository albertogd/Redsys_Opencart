<?php
// Heading
$_['heading_title'] = 'Payment Processing Failed';
$_['heading_title_customer'] = 'Payment Processing Failed';

// Text
$_['text_customer'] = '<p>Sorry, your order has not been processed. <p></p>Unfortunately there was an error while processing your payment.</p><p>Please, try again and verify the payment information.</p><p>We apologize for any inconvenience, please <a href="%s">contact us</a> if you are having difficulties making your payment.</p>';
$_['text_basket']   = 'Basket';
$_['text_checkout'] = 'Checkout';
$_['text_error']  = 'Error';
?>