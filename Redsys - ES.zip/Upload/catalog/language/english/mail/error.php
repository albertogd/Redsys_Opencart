<?php
// Text
$_['text_new_subject_error']          = '%s - Payment failed - Order %s';
$_['text_new_received_error']          = 'The order could not be processed due to an error in the payment process';
?>